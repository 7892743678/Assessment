import React from "react";
import {createRoot} from "react-dom/client"

// import Apphoc4 from "./Apphoc4";
// import Apphoc3 from "./Apphoc3";
// import App from './App';
// import Appcrud from './Appcrud';
// import Appprac from "./Appprac";
// import Mediaquerys from "./Mediaquerys";
// import Practice from './Practice';
// import Appcontextapi from './Appcontextapi';
// import Contextprovider from "./context api/Contextprovider";
import { Appassignment } from './Appassignment';


// createRoot(document.getElementById("root")).render(<App/>)
// createRoot(document.getElementById("root")).render(<Apphoc3/>)
// createRoot(document.getElementById("root")).render(<Apphoc4/>)
// createRoot(document.getElementById("root")).render(<Appcrud/>)
// createRoot(document.getElementById("root")).render(<Appprac/>)
// createRoot(document.getElementById("root")).render(<Mediaquerys/>)

// createRoot(document.getElementById("root")).render(<Practice/>)

// createRoot(document.getElementById("root")).render(
// <Contextprovider>
// <Appcontextapi/>
// </Contextprovider>)

createRoot(document.getElementById("root")).render(<Appassignment/>)